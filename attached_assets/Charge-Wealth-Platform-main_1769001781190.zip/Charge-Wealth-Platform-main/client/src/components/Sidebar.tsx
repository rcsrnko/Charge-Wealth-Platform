import { useState, ReactNode } from 'react';
import { useLocation, Link } from 'wouter';
import styles from './Sidebar.module.css';

interface NavItem {
  id: string;
  label: string;
  path: string;
  icon: ReactNode;
  description: string;
  lockedDescription: string;
  badge?: string;
  requiredScore: number;
}

const navItems: NavItem[] = [
  { 
    id: 'command-center', 
    label: 'Command Center', 
    path: '/dashboard',
    description: 'Your Wealth Readiness',
    lockedDescription: 'Your Wealth Readiness',
    requiredScore: 0,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7"/>
        <rect x="14" y="3" width="7" height="7"/>
        <rect x="14" y="14" width="7" height="7"/>
        <rect x="3" y="14" width="7" height="7"/>
      </svg>
    )
  },
  { 
    id: 'ai-advisor', 
    label: 'AI Advisor', 
    path: '/dashboard/ai',
    description: 'Your Private CFO',
    lockedDescription: 'Your Private CFO',
    badge: 'Start Here',
    requiredScore: 0,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
        <circle cx="8" cy="14" r="1.5"/>
        <circle cx="16" cy="14" r="1.5"/>
      </svg>
    )
  },
  { 
    id: 'tax-intel', 
    label: 'Tax Advisor', 
    path: '/dashboard/tax-intel',
    description: 'Tax Optimization Engine',
    lockedDescription: 'Unlock Tax Savings',
    requiredScore: 0,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>
      </svg>
    )
  },
  { 
    id: 'allocation', 
    label: 'Portfolio Engine', 
    path: '/dashboard/allocation',
    description: 'CFA-Level Analysis',
    lockedDescription: 'Reveal Hidden Risk',
    requiredScore: 0,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2a10 10 0 1 0 10 10"/>
        <path d="M12 2v10l6.5-3.5"/>
        <path d="M12 12l6.5 3.5"/>
      </svg>
    )
  },
  { 
    id: 'playbooks', 
    label: 'Playbooks', 
    path: '/dashboard/playbooks',
    description: 'Action Plans',
    lockedDescription: 'Step-by-Step Actions',
    requiredScore: 20,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
        <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/>
        <rect x="9" y="3" width="6" height="4" rx="1"/>
        <path d="M9 12l2 2 4-4"/>
      </svg>
    )
  },
  { 
    id: 'referrals', 
    label: 'Referrals', 
    path: '/dashboard/referrals',
    description: 'Earn $50 Per Friend',
    lockedDescription: 'Share & Earn',
    requiredScore: 0,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
        <path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/>
        <circle cx="9" cy="7" r="4"/>
        <path d="M22 21v-2a4 4 0 00-3-3.87"/>
        <path d="M16 3.13a4 4 0 010 7.75"/>
      </svg>
    )
  },
];

interface SidebarProps {
  onCollapse?: (collapsed: boolean) => void;
  wealthScore?: number;
}

export default function Sidebar({ onCollapse, wealthScore = 0 }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [location] = useLocation();

  const toggleCollapse = () => {
    const newState = !isCollapsed;
    setIsCollapsed(newState);
    onCollapse?.(newState);
  };

  const isPathActive = (path: string) => location === path;
  
  const isItemLocked = (item: NavItem) => wealthScore < item.requiredScore;

  const handleLockedClick = (e: React.MouseEvent, item: NavItem) => {
    if (isItemLocked(item)) {
      e.preventDefault();
    }
  };

  return (
    <aside className={`${styles.sidebar} ${isCollapsed ? styles.collapsed : ''}`}>
      <div className={styles.header}>
        {!isCollapsed && (
          <div className={styles.logoSection}>
            <h1 className={styles.logo}>Charge</h1>
            <span className={styles.tagline}>Wealth</span>
          </div>
        )}
        <button
          className={styles.toggleBtn}
          onClick={toggleCollapse}
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed ? '→' : '←'}
        </button>
      </div>

      <nav className={styles.nav}>
        {navItems.map((item) => {
          const locked = isItemLocked(item);
          return (
            <Link key={item.id} href={locked ? '#' : item.path}>
              <a 
                className={`${styles.navItem} ${isPathActive(item.path) ? styles.active : ''} ${item.badge ? styles.hasBadge : ''} ${locked ? styles.locked : ''}`}
                onClick={(e) => handleLockedClick(e, item)}
              >
                <div className={styles.navIcon}>
                  {item.icon}
                  {locked && (
                    <div className={styles.lockIcon}>
                      <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C9.24 2 7 4.24 7 7v2H6c-1.1 0-2 .9-2 2v9c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-9c0-1.1-.9-2-2-2h-1V7c0-2.76-2.24-5-5-5zm0 2c1.66 0 3 1.34 3 3v2H9V7c0-1.66 1.34-3 3-3zm0 10c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"/>
                      </svg>
                    </div>
                  )}
                </div>
                {!isCollapsed && (
                  <div className={styles.navText}>
                    <div className={styles.labelRow}>
                      <span className={styles.label}>{item.label}</span>
                      {item.badge && !locked && <span className={styles.badge}>{item.badge}</span>}
                      {locked && <span className={styles.lockedBadge}>Locked</span>}
                    </div>
                    <span className={styles.description}>
                      {locked ? item.lockedDescription : item.description}
                    </span>
                  </div>
                )}
              </a>
            </Link>
          );
        })}
      </nav>

      {!isCollapsed && (
        <div className={styles.footer}>
          <div className={styles.scorePreview}>
            <div className={styles.scoreMini}>
              <span className={styles.scoreValue}>{wealthScore}%</span>
              <span className={styles.scoreLabel}>Wealth Readiness</span>
            </div>
            <div className={styles.scoreBar}>
              <div 
                className={styles.scoreProgress} 
                style={{ width: `${wealthScore}%` }}
              />
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
