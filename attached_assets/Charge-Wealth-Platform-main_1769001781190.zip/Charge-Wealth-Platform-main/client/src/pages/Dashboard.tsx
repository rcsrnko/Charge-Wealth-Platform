import { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Route, Switch, useLocation } from 'wouter';
import Sidebar from '../components/Sidebar';
import WealthReadiness from '../components/WealthReadiness';
import CfoRecommendations from '../components/CfoRecommendations';
import ChargeTaxIntel from '../modules/ChargeTaxIntel';
import ChargeAllocation from '../modules/ChargeAllocation';
import ChargeAI from '../modules/ChargeAI';
import Playbooks from '../modules/Playbooks';
import ReferralDashboard from '../modules/ReferralDashboard';
import OnboardingWizard from '../components/OnboardingWizard';
import styles from './Dashboard.module.css';

interface UserDataState {
  hasTaxData: boolean;
  hasPositions: boolean;
  hasProfile: boolean;
  hasCashFlow: boolean;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [location] = useLocation();
  const [userData, setUserData] = useState<UserDataState>({
    hasTaxData: false,
    hasPositions: false,
    hasProfile: false,
    hasCashFlow: false
  });
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    const checkUserData = async () => {
      try {
        const [contextRes, portfolioRes, taxRes] = await Promise.all([
          fetch('/api/charge-ai/context', { credentials: 'include' }),
          fetch('/api/allocation/portfolio', { credentials: 'include' }),
          fetch('/api/tax-intel/current', { credentials: 'include' })
        ]);
        
        const contextData = contextRes.ok ? await contextRes.json() : null;
        const portfolioData = portfolioRes.ok ? await portfolioRes.json() : null;
        const taxData = taxRes.ok ? await taxRes.json() : null;
        
        const hasProfile = !!contextData?.hasProfile;
        const hasPositions = portfolioData?.portfolio?.positions?.length > 0;
        const hasTaxData = !!taxData?.taxData || !!contextData?.hasTaxData;
        
        setUserData({
          hasTaxData,
          hasPositions,
          hasProfile,
          hasCashFlow: false
        });
      } catch (err) {
        console.error('Failed to check user data:', err);
      }
    };
    
    checkUserData();
  }, []);

  useEffect(() => {
    // Check if we should show onboarding from URL param
    const params = new URLSearchParams(window.location.search);
    if (params.get('showOnboarding') === 'true') {
      setShowOnboarding(true);
      // Clean up URL without page reload
      window.history.replaceState({}, '', '/dashboard');
    }
  }, []);

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  const isMainDashboard = location === '/dashboard';
  
  const calculateWealthScore = () => {
    let score = 0;
    if (userData.hasProfile) score += 20;
    if (userData.hasTaxData) score += 30;
    if (userData.hasPositions) score += 30;
    if (userData.hasCashFlow) score += 20;
    return score;
  };
  
  const wealthScore = calculateWealthScore();

  const getPageTitle = () => {
    if (isMainDashboard) return 'Command Center';
    if (location.includes('/ai')) return 'AI Advisor';
    if (location.includes('tax-intel')) return 'Tax Advisor';
    if (location.includes('allocation')) return 'Portfolio Engine';
    if (location.includes('playbooks')) return 'Playbooks';
    if (location.includes('referrals')) return 'Referral Program';
    return 'Charge Wealth';
  };

  const isModuleLocked = (module: string) => {
    if (module === 'ai' || module === 'command-center') return false;
    if (module === 'playbooks') return wealthScore < 20;
    // Tax Advisor and Portfolio Engine are always accessible so users can add data
    return false;
  };

  // Handle onboarding completion
  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
  };

  // Show onboarding wizard if triggered
  if (showOnboarding) {
    return <OnboardingWizard onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className={styles.dashboardLayout}>
      <Sidebar onCollapse={setSidebarCollapsed} wealthScore={wealthScore} />
      
      <div className={`${styles.mainContent} ${sidebarCollapsed ? styles.collapsed : ''}`}>
        <header className={styles.topHeader}>
          <div className={styles.headerContent}>
            <div className={styles.headerLeft}>
              <h1 className={styles.pageTitle}>{getPageTitle()}</h1>
            </div>
            <div className={styles.userSection}>
              <span className={styles.userName}>
                {user?.firstName || user?.email}
              </span>
              <button onClick={handleLogout} className={styles.logoutButton}>
                Sign Out
              </button>
            </div>
          </div>
        </header>

        <div className={styles.pageContent}>
          <Switch>
            <Route path="/dashboard">
              <div className={styles.commandCenter}>
                <div className={styles.onboardingLayout}>
                  <div className={styles.primaryColumn}>
                    <div className={styles.aiAdvisorPromo}>
                      <div className={styles.promoHeader}>
                        <div className={styles.promoIcon}>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                            <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
                            <circle cx="8" cy="14" r="1.5"/>
                            <circle cx="16" cy="14" r="1.5"/>
                          </svg>
                        </div>
                        <div className={styles.promoText}>
                          <h2 className={styles.promoTitle}>Your AI Advisor</h2>
                          <p className={styles.promoDesc}>
                            Ask any financial question. Get clear answers based on your actual data.
                          </p>
                        </div>
                      </div>
                      <a href="/dashboard/ai" className={styles.startButton}>
                        Start Conversation
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M5 12h14M12 5l7 7-7 7"/>
                        </svg>
                      </a>
                    </div>

                    <WealthReadiness 
                      hasTaxData={userData.hasTaxData}
                      hasPositions={userData.hasPositions}
                      hasProfile={userData.hasProfile}
                      hasCashFlow={userData.hasCashFlow}
                    />
                    
                    <CfoRecommendations />
                  </div>

                  <div className={styles.secondaryColumn}>
                    <h3 className={styles.columnTitle}>Unlock More Tools</h3>
                    
                    <div className={styles.lockedModules}>
                      <div className={`${styles.modulePreview} ${!isModuleLocked('tax-intel') ? styles.unlocked : ''}`}>
                        <div className={styles.moduleIcon}>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                            <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>
                          </svg>
                          {isModuleLocked('tax-intel') && (
                            <div className={styles.moduleLock}>
                              <svg viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C9.24 2 7 4.24 7 7v2H6c-1.1 0-2 .9-2 2v9c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-9c0-1.1-.9-2-2-2h-1V7c0-2.76-2.24-5-5-5zm0 2c1.66 0 3 1.34 3 3v2H9V7c0-1.66 1.34-3 3-3z"/>
                              </svg>
                            </div>
                          )}
                        </div>
                        <div className={styles.moduleInfo}>
                          <h4 className={styles.moduleName}>Tax Advisor</h4>
                          <p className={styles.moduleUnlock}>
                            {isModuleLocked('tax-intel') 
                              ? 'Upload tax return to unlock' 
                              : 'Find tax-saving opportunities'}
                          </p>
                        </div>
                        {!isModuleLocked('tax-intel') && (
                          <a href="/dashboard/tax-intel" className={styles.moduleLink}>Open</a>
                        )}
                      </div>

                      <div className={`${styles.modulePreview} ${!isModuleLocked('allocation') ? styles.unlocked : ''}`}>
                        <div className={styles.moduleIcon}>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                            <path d="M12 2a10 10 0 1 0 10 10"/>
                            <path d="M12 2v10l6.5-3.5"/>
                            <path d="M12 12l6.5 3.5"/>
                          </svg>
                          {isModuleLocked('allocation') && (
                            <div className={styles.moduleLock}>
                              <svg viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C9.24 2 7 4.24 7 7v2H6c-1.1 0-2 .9-2 2v9c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-9c0-1.1-.9-2-2-2h-1V7c0-2.76-2.24-5-5-5zm0 2c1.66 0 3 1.34 3 3v2H9V7c0-1.66 1.34-3 3-3z"/>
                              </svg>
                            </div>
                          )}
                        </div>
                        <div className={styles.moduleInfo}>
                          <h4 className={styles.moduleName}>Portfolio Engine</h4>
                          <p className={styles.moduleUnlock}>
                            {isModuleLocked('allocation') 
                              ? 'Add positions to unlock' 
                              : 'Analyze risk & allocation'}
                          </p>
                        </div>
                        {!isModuleLocked('allocation') && (
                          <a href="/dashboard/allocation" className={styles.moduleLink}>Open</a>
                        )}
                      </div>

                      <div className={`${styles.modulePreview} ${!isModuleLocked('playbooks') ? styles.unlocked : ''}`}>
                        <div className={styles.moduleIcon}>
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                            <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/>
                            <rect x="9" y="3" width="6" height="4" rx="1"/>
                            <path d="M9 12l2 2 4-4"/>
                          </svg>
                          {isModuleLocked('playbooks') && (
                            <div className={styles.moduleLock}>
                              <svg viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C9.24 2 7 4.24 7 7v2H6c-1.1 0-2 .9-2 2v9c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-9c0-1.1-.9-2-2-2h-1V7c0-2.76-2.24-5-5-5zm0 2c1.66 0 3 1.34 3 3v2H9V7c0-1.66 1.34-3 3-3z"/>
                              </svg>
                            </div>
                          )}
                        </div>
                        <div className={styles.moduleInfo}>
                          <h4 className={styles.moduleName}>Playbooks</h4>
                          <p className={styles.moduleUnlock}>
                            {isModuleLocked('playbooks') 
                              ? 'Complete profile to unlock' 
                              : 'Step-by-step action plans'}
                          </p>
                        </div>
                        {!isModuleLocked('playbooks') && (
                          <a href="/dashboard/playbooks" className={styles.moduleLink}>Open</a>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className={styles.disclaimer}>
                  Charge Wealth provides decision support based on your data. We don't sell products, manage money, or give personalized recommendations. Consult qualified professionals before acting.
                </div>
              </div>
            </Route>
            <Route path="/dashboard/ai" component={ChargeAI} />
            <Route path="/dashboard/tax-intel">
              {isModuleLocked('tax-intel') ? (
                <LockedModule 
                  title="Tax Advisor"
                  description="Upload your tax return to unlock tax optimization insights."
                  requiredAction="Upload Tax Return"
                  actionPath="/dashboard/ai"
                />
              ) : (
                <ChargeTaxIntel />
              )}
            </Route>
            <Route path="/dashboard/allocation">
              {isModuleLocked('allocation') ? (
                <LockedModule 
                  title="Portfolio Engine"
                  description="Add your portfolio positions to unlock CFA-level analysis."
                  requiredAction="Add Portfolio Positions"
                  actionPath="/dashboard/ai"
                />
              ) : (
                <ChargeAllocation />
              )}
            </Route>
            <Route path="/dashboard/playbooks">
              {isModuleLocked('playbooks') ? (
                <LockedModule 
                  title="Playbooks"
                  description="Complete your financial profile to unlock step-by-step action plans."
                  requiredAction="Complete Profile"
                  actionPath="/dashboard/ai"
                />
              ) : (
                <Playbooks />
              )}
            </Route>
            <Route path="/dashboard/referrals" component={ReferralDashboard} />
          </Switch>
        </div>
      </div>
    </div>
  );
}

interface LockedModuleProps {
  title: string;
  description: string;
  requiredAction: string;
  actionPath: string;
}

function LockedModule({ title, description, requiredAction, actionPath }: LockedModuleProps) {
  return (
    <div className={styles.lockedModulePage}>
      <div className={styles.lockedContent}>
        <div className={styles.lockedIcon}>
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C9.24 2 7 4.24 7 7v2H6c-1.1 0-2 .9-2 2v9c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-9c0-1.1-.9-2-2-2h-1V7c0-2.76-2.24-5-5-5zm0 2c1.66 0 3 1.34 3 3v2H9V7c0-1.66 1.34-3 3-3zm0 10c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2z"/>
          </svg>
        </div>
        <h2 className={styles.lockedTitle}>{title}</h2>
        <p className={styles.lockedDesc}>{description}</p>
        <a href={actionPath} className={styles.lockedAction}>
          {requiredAction}
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14M12 5l7 7-7 7"/>
          </svg>
        </a>
      </div>
    </div>
  );
}
