import { useState, useEffect } from 'react';
import styles from './Playbooks.module.css';

interface PlaybookStep {
  id: string;
  title: string;
  description: string;
  actionType: string;
  isCompleted: boolean;
  completedAt?: string;
  notes?: string;
}

interface Playbook {
  id: number;
  title: string;
  description?: string;
  category?: string;
  steps: PlaybookStep[];
  status: string;
  progress: number;
  estimatedImpact?: string;
  targetDate?: string;
  createdAt: string;
}

interface PlaybookTemplate {
  id: number;
  title: string;
  description: string;
  category: string;
  steps: PlaybookStep[];
  estimatedTimeWeeks?: number;
  difficulty?: string;
}

const CATEGORIES = [
  { id: 'tax_optimization', label: 'Tax Optimization', icon: '📋' },
  { id: 'investment', label: 'Investment Strategy', icon: '📈' },
  { id: 'debt_payoff', label: 'Debt Payoff', icon: '💳' },
  { id: 'retirement', label: 'Retirement Planning', icon: '🏖️' },
  { id: 'emergency_fund', label: 'Emergency Fund', icon: '🛡️' },
  { id: 'custom', label: 'Custom', icon: '✏️' },
];

export default function Playbooks() {
  const [playbooks, setPlaybooks] = useState<Playbook[]>([]);
  const [templates, setTemplates] = useState<PlaybookTemplate[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activePlaybook, setActivePlaybook] = useState<Playbook | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [newPlaybook, setNewPlaybook] = useState({
    title: '',
    description: '',
    category: 'custom',
    steps: [] as PlaybookStep[],
  });
  const [newStep, setNewStep] = useState({ title: '', description: '' });

  useEffect(() => {
    loadPlaybooks();
    loadTemplates();
  }, []);

  const loadPlaybooks = async () => {
    try {
      const response = await fetch('/api/playbooks', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        setPlaybooks(data.playbooks || []);
      }
    } catch (err) {
      console.error('Failed to load playbooks:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const loadTemplates = async () => {
    try {
      const response = await fetch('/api/playbooks/templates', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        setTemplates(data.templates || []);
      }
    } catch (err) {
      console.error('Failed to load templates:', err);
    }
  };

  const createPlaybook = async () => {
    if (!newPlaybook.title.trim() || newPlaybook.steps.length === 0) return;

    try {
      const response = await fetch('/api/playbooks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(newPlaybook),
      });

      if (response.ok) {
        const data = await response.json();
        setPlaybooks(prev => [data.playbook, ...prev]);
        setShowCreateModal(false);
        setNewPlaybook({ title: '', description: '', category: 'custom', steps: [] });
      }
    } catch (err) {
      console.error('Failed to create playbook:', err);
    }
  };

  const createFromTemplate = async (template: PlaybookTemplate) => {
    try {
      const response = await fetch('/api/playbooks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          title: template.title,
          description: template.description,
          category: template.category,
          steps: template.steps.map(s => ({ ...s, isCompleted: false })),
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setPlaybooks(prev => [data.playbook, ...prev]);
        setShowTemplates(false);
      }
    } catch (err) {
      console.error('Failed to create playbook from template:', err);
    }
  };

  const toggleStepComplete = async (playbookId: number, stepId: string) => {
    const playbook = playbooks.find(p => p.id === playbookId);
    if (!playbook) return;

    const updatedSteps = playbook.steps.map(step => {
      if (step.id === stepId) {
        return {
          ...step,
          isCompleted: !step.isCompleted,
          completedAt: !step.isCompleted ? new Date().toISOString() : undefined,
        };
      }
      return step;
    });

    const completedCount = updatedSteps.filter(s => s.isCompleted).length;
    const progress = Math.round((completedCount / updatedSteps.length) * 100);
    const status = progress === 100 ? 'completed' : 'active';

    try {
      const response = await fetch(`/api/playbooks/${playbookId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ steps: updatedSteps, progress, status }),
      });

      if (response.ok) {
        setPlaybooks(prev => prev.map(p => 
          p.id === playbookId ? { ...p, steps: updatedSteps, progress, status } : p
        ));
        if (activePlaybook?.id === playbookId) {
          setActivePlaybook({ ...activePlaybook, steps: updatedSteps, progress, status });
        }
      }
    } catch (err) {
      console.error('Failed to update step:', err);
    }
  };

  const deletePlaybook = async (id: number) => {
    try {
      const response = await fetch(`/api/playbooks/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (response.ok) {
        setPlaybooks(prev => prev.filter(p => p.id !== id));
        if (activePlaybook?.id === id) {
          setActivePlaybook(null);
        }
      }
    } catch (err) {
      console.error('Failed to delete playbook:', err);
    }
  };

  const addStep = () => {
    if (!newStep.title.trim()) return;
    
    setNewPlaybook(prev => ({
      ...prev,
      steps: [
        ...prev.steps,
        {
          id: `step-${Date.now()}`,
          title: newStep.title,
          description: newStep.description,
          actionType: 'task',
          isCompleted: false,
        },
      ],
    }));
    setNewStep({ title: '', description: '' });
  };

  const removeStep = (stepId: string) => {
    setNewPlaybook(prev => ({
      ...prev,
      steps: prev.steps.filter(s => s.id !== stepId),
    }));
  };

  const getCategoryInfo = (categoryId: string) => {
    return CATEGORIES.find(c => c.id === categoryId) || CATEGORIES[CATEGORIES.length - 1];
  };

  if (isLoading) {
    return (
      <div className={styles.container}>
        <div className={styles.loading}>Loading playbooks...</div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.mainPanel}>
        <div className={styles.header}>
          <div className={styles.headerContent}>
            <h1 className={styles.title}>Custom Playbooks</h1>
            <p className={styles.subtitle}>Step-by-step action plans for your financial goals</p>
          </div>
          <div className={styles.headerActions}>
            <button className={styles.templateButton} onClick={() => setShowTemplates(true)}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                <path d="M4 4h16v16H4z"/>
                <path d="M4 12h16M12 4v16"/>
              </svg>
              Use Template
            </button>
            <button className={styles.createButton} onClick={() => setShowCreateModal(true)}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
                <path d="M12 5v14M5 12h14"/>
              </svg>
              Create Playbook
            </button>
          </div>
        </div>

        {playbooks.length === 0 ? (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" width="48" height="48">
                <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/>
                <rect x="9" y="3" width="6" height="4" rx="1"/>
                <path d="M9 12l2 2 4-4"/>
              </svg>
            </div>
            <h3>No playbooks yet</h3>
            <p>Create step-by-step action plans to stay on track with your financial goals.</p>
            <div className={styles.emptyActions}>
              <button className={styles.templateButton} onClick={() => setShowTemplates(true)}>
                Browse Templates
              </button>
              <button className={styles.createButton} onClick={() => setShowCreateModal(true)}>
                Create Custom Playbook
              </button>
            </div>
          </div>
        ) : (
          <div className={styles.playbookGrid}>
            {playbooks.map(playbook => (
              <div 
                key={playbook.id} 
                className={`${styles.playbookCard} ${activePlaybook?.id === playbook.id ? styles.active : ''}`}
                onClick={() => setActivePlaybook(playbook)}
              >
                <div className={styles.cardHeader}>
                  <span className={styles.categoryBadge}>
                    {getCategoryInfo(playbook.category || 'custom').icon} {getCategoryInfo(playbook.category || 'custom').label}
                  </span>
                  <span className={`${styles.statusBadge} ${styles[playbook.status]}`}>
                    {playbook.status === 'completed' ? 'Complete' : 'Active'}
                  </span>
                </div>
                <h3 className={styles.cardTitle}>{playbook.title}</h3>
                {playbook.description && (
                  <p className={styles.cardDesc}>{playbook.description}</p>
                )}
                <div className={styles.progressSection}>
                  <div className={styles.progressBar}>
                    <div className={styles.progressFill} style={{ width: `${playbook.progress}%` }}/>
                  </div>
                  <span className={styles.progressLabel}>{playbook.progress}% complete</span>
                </div>
                <div className={styles.cardFooter}>
                  <span className={styles.stepCount}>
                    {playbook.steps.filter(s => s.isCompleted).length} / {playbook.steps.length} steps
                  </span>
                  <button 
                    className={styles.deleteBtn}
                    onClick={(e) => { e.stopPropagation(); deletePlaybook(playbook.id); }}
                  >
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                      <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {activePlaybook && (
        <div className={styles.detailPanel}>
          <div className={styles.detailHeader}>
            <div>
              <span className={styles.categoryBadge}>
                {getCategoryInfo(activePlaybook.category || 'custom').icon} {getCategoryInfo(activePlaybook.category || 'custom').label}
              </span>
              <h2 className={styles.detailTitle}>{activePlaybook.title}</h2>
              {activePlaybook.description && (
                <p className={styles.detailDesc}>{activePlaybook.description}</p>
              )}
            </div>
            <button className={styles.closeBtn} onClick={() => setActivePlaybook(null)}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>

          <div className={styles.progressSection}>
            <div className={styles.progressBar}>
              <div className={styles.progressFill} style={{ width: `${activePlaybook.progress}%` }}/>
            </div>
            <span className={styles.progressLabel}>
              {activePlaybook.progress}% complete - {activePlaybook.steps.filter(s => s.isCompleted).length} of {activePlaybook.steps.length} steps
            </span>
          </div>

          <div className={styles.stepsList}>
            <h3 className={styles.stepsTitle}>Action Steps</h3>
            {activePlaybook.steps.map((step, index) => (
              <div 
                key={step.id} 
                className={`${styles.stepItem} ${step.isCompleted ? styles.completed : ''}`}
              >
                <button 
                  className={styles.stepCheckbox}
                  onClick={() => toggleStepComplete(activePlaybook.id, step.id)}
                >
                  {step.isCompleted ? (
                    <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
                      <circle cx="12" cy="12" r="10"/>
                    </svg>
                  )}
                </button>
                <div className={styles.stepContent}>
                  <span className={styles.stepNumber}>Step {index + 1}</span>
                  <h4 className={styles.stepTitle}>{step.title}</h4>
                  {step.description && (
                    <p className={styles.stepDesc}>{step.description}</p>
                  )}
                  {step.completedAt && (
                    <span className={styles.completedAt}>
                      Completed {new Date(step.completedAt).toLocaleDateString()}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showCreateModal && (
        <div className={styles.modal}>
          <div className={styles.modalContent}>
            <div className={styles.modalHeader}>
              <h2>Create New Playbook</h2>
              <button className={styles.closeBtn} onClick={() => setShowCreateModal(false)}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
                  <path d="M18 6L6 18M6 6l12 12"/>
                </svg>
              </button>
            </div>

            <div className={styles.modalBody}>
              <div className={styles.formGroup}>
                <label>Title</label>
                <input 
                  type="text"
                  value={newPlaybook.title}
                  onChange={(e) => setNewPlaybook(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., Max Out 401(k) This Year"
                />
              </div>

              <div className={styles.formGroup}>
                <label>Description (optional)</label>
                <textarea 
                  value={newPlaybook.description}
                  onChange={(e) => setNewPlaybook(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Briefly describe your goal..."
                  rows={2}
                />
              </div>

              <div className={styles.formGroup}>
                <label>Category</label>
                <div className={styles.categoryGrid}>
                  {CATEGORIES.map(cat => (
                    <button 
                      key={cat.id}
                      className={`${styles.categoryOption} ${newPlaybook.category === cat.id ? styles.selected : ''}`}
                      onClick={() => setNewPlaybook(prev => ({ ...prev, category: cat.id }))}
                    >
                      <span>{cat.icon}</span>
                      <span>{cat.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className={styles.formGroup}>
                <label>Steps</label>
                <div className={styles.stepsBuilder}>
                  {newPlaybook.steps.map((step, index) => (
                    <div key={step.id} className={styles.builtStep}>
                      <span className={styles.stepNumber}>{index + 1}</span>
                      <div className={styles.stepInfo}>
                        <strong>{step.title}</strong>
                        {step.description && <p>{step.description}</p>}
                      </div>
                      <button className={styles.removeStepBtn} onClick={() => removeStep(step.id)}>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
                          <path d="M18 6L6 18M6 6l12 12"/>
                        </svg>
                      </button>
                    </div>
                  ))}
                  <div className={styles.addStepForm}>
                    <input 
                      type="text"
                      value={newStep.title}
                      onChange={(e) => setNewStep(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Step title..."
                      onKeyDown={(e) => e.key === 'Enter' && addStep()}
                    />
                    <input 
                      type="text"
                      value={newStep.description}
                      onChange={(e) => setNewStep(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Description (optional)"
                    />
                    <button className={styles.addStepBtn} onClick={addStep}>Add Step</button>
                  </div>
                </div>
              </div>
            </div>

            <div className={styles.modalFooter}>
              <button className={styles.cancelBtn} onClick={() => setShowCreateModal(false)}>Cancel</button>
              <button 
                className={styles.saveBtn} 
                onClick={createPlaybook}
                disabled={!newPlaybook.title.trim() || newPlaybook.steps.length === 0}
              >
                Create Playbook
              </button>
            </div>
          </div>
        </div>
      )}

      {showTemplates && (
        <div className={styles.modal}>
          <div className={styles.modalContent}>
            <div className={styles.modalHeader}>
              <h2>Playbook Templates</h2>
              <button className={styles.closeBtn} onClick={() => setShowTemplates(false)}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
                  <path d="M18 6L6 18M6 6l12 12"/>
                </svg>
              </button>
            </div>

            <div className={styles.templateGrid}>
              {templates.length > 0 ? templates.map(template => (
                <div key={template.id} className={styles.templateCard}>
                  <span className={styles.categoryBadge}>
                    {getCategoryInfo(template.category).icon} {getCategoryInfo(template.category).label}
                  </span>
                  <h3>{template.title}</h3>
                  <p>{template.description}</p>
                  <div className={styles.templateMeta}>
                    <span>{template.steps.length} steps</span>
                    {template.estimatedTimeWeeks && <span>{template.estimatedTimeWeeks} weeks</span>}
                    {template.difficulty && <span className={styles.difficulty}>{template.difficulty}</span>}
                  </div>
                  <button className={styles.useTemplateBtn} onClick={() => createFromTemplate(template)}>
                    Use This Template
                  </button>
                </div>
              )) : (
                <div className={styles.noTemplates}>
                  <p>No templates available yet. Create a custom playbook instead!</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
