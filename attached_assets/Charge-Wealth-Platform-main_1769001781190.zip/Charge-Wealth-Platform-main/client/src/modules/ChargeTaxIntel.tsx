import { useState, useEffect } from 'react';
import styles from './ChargeTaxIntel.module.css';

interface TaxMetrics {
  taxYear: number;
  totalIncome: number;
  agi: number;
  taxableIncome: number;
  totalFederalTax: number;
  effectiveTaxRate: number;
  marginalTaxBracket: number;
  filingStatus: string;
  incomeBreakdown: {
    wages: number;
    dividends: number;
    capitalGains: number;
    business: number;
    other: number;
  };
  insights: Array<{
    type: string;
    severity: string;
    title: string;
    description: string;
    potentialImpact?: number;
    action?: string;
  }>;
}

interface Scenario {
  id: number;
  name: string;
  type: string;
  inputs: any;
  results?: {
    newTax: number;
    taxDelta: number;
    effectiveRate: number;
  };
}

interface TaxDeadline {
  date: string;
  title: string;
  description: string;
  impact: string;
  urgency: 'now' | 'soon' | 'plan';
}

export default function ChargeTaxIntel() {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [taxData, setTaxData] = useState<TaxMetrics | null>(null);
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [showScenarioBuilder, setShowScenarioBuilder] = useState(false);
  const [activeScenario, setActiveScenario] = useState<string>('');
  const [scenarioInputs, setScenarioInputs] = useState<any>({});
  const [isCalculating, setIsCalculating] = useState(false);

  const taxDeadlines: TaxDeadline[] = [
    {
      date: 'Dec 31',
      title: 'Tax-Loss Harvesting Deadline',
      description: 'Last day to realize losses to offset gains',
      impact: 'Save up to $3,200 in taxes',
      urgency: 'now'
    },
    {
      date: 'Jan 15',
      title: 'Q4 Estimated Payment Due',
      description: 'Final quarterly estimated tax payment',
      impact: 'Avoid underpayment penalty',
      urgency: 'soon'
    },
    {
      date: 'Apr 15',
      title: 'IRA Contribution Deadline',
      description: 'Last day for prior-year IRA contributions',
      impact: 'Up to $7,000 tax deduction',
      urgency: 'plan'
    },
    {
      date: 'Apr 15',
      title: 'Tax Filing Deadline',
      description: 'File return or extension by this date',
      impact: 'Avoid late filing penalties',
      urgency: 'plan'
    }
  ];

  useEffect(() => {
    loadTaxData();
    loadScenarios();
  }, []);

  const loadTaxData = async () => {
    try {
      const response = await fetch('/api/tax-intel/current', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        if (data.taxData) {
          setTaxData(data.taxData);
        }
      }
    } catch (err) {
      console.error('Failed to load tax data:', err);
    }
  };

  const loadScenarios = async () => {
    try {
      const response = await fetch('/api/tax-intel/scenarios', { credentials: 'include' });
      if (response.ok) {
        const data = await response.json();
        setScenarios(data.scenarios || []);
      }
    } catch (err) {
      console.error('Failed to load scenarios:', err);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files?.[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const uploadAndAnalyze = async () => {
    if (!file) return;

    setIsUploading(true);
    try {
      const response = await fetch('/api/tax-intel/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ filename: file.name }),
      });

      if (!response.ok) throw new Error('Analysis failed');

      const data = await response.json();
      setTaxData(data.taxData);
      setFile(null);
    } catch (err) {
      console.error('Upload error:', err);
    } finally {
      setIsUploading(false);
    }
  };

  const runScenario = async () => {
    if (!activeScenario) return;

    setIsCalculating(true);
    try {
      const response = await fetch('/api/tax-intel/run-scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          scenarioType: activeScenario,
          inputs: scenarioInputs,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setScenarios(prev => [data.scenario, ...prev]);
        setShowScenarioBuilder(false);
        setActiveScenario('');
        setScenarioInputs({});
      }
    } catch (err) {
      console.error('Scenario error:', err);
    } finally {
      setIsCalculating(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const scenarioTypes = [
    { id: 'gain_realization', name: 'Realize Gains', icon: '📈', description: 'See tax on selling positions' },
    { id: 'charitable_giving', name: 'Charitable Gift', icon: '🎁', description: 'Calculate donation deduction' },
    { id: 'retirement_contribution', name: 'Boost 401k/IRA', icon: '💰', description: 'See tax savings from contributions' },
    { id: 'roth_conversion', name: 'Roth Conversion', icon: '🔄', description: 'Model conversion tax impact' },
  ];

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.headerContent}>
          <h1 className={styles.title}>Tax Command Center</h1>
          <p className={styles.subtitle}>See exactly how much you can save—and when to act</p>
        </div>
      </div>

      {!taxData ? (
        <div className={styles.uploadSection}>
          <div className={styles.uploadContent}>
            <div 
              className={`${styles.dropzone} ${file ? styles.hasFile : ''}`}
              onDrop={handleDrop}
              onDragOver={(e) => e.preventDefault()}
            >
              {file ? (
                <div className={styles.filePreview}>
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                  </svg>
                  <span className={styles.fileName}>{file.name}</span>
                  <button 
                    className={styles.removeFile}
                    onClick={() => setFile(null)}
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <>
                  <div className={styles.uploadIcon}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                  </div>
                  <h3>Unlock Your Tax Savings</h3>
                  <p>Upload your Form 1040 to discover opportunities worth $2,000-$15,000</p>
                  <div className={styles.uploadBenefits}>
                    <span>See your real effective rate</span>
                    <span>Find missed deductions</span>
                    <span>Model "what-if" scenarios</span>
                  </div>
                  <input 
                    type="file" 
                    accept=".pdf"
                    onChange={handleFileChange}
                    className={styles.fileInput}
                  />
                </>
              )}
            </div>
            {file && (
              <button 
                className={styles.analyzeButton}
                onClick={uploadAndAnalyze}
                disabled={isUploading}
              >
                {isUploading ? 'Analyzing...' : 'Analyze & Find Savings'}
              </button>
            )}
          </div>

          <div className={styles.calendarPreview}>
            <h3 className={styles.calendarTitle}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                <line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
              Upcoming Tax Deadlines
            </h3>
            <div className={styles.deadlinesList}>
              {taxDeadlines.map((deadline, i) => (
                <div key={i} className={`${styles.deadlineCard} ${styles[deadline.urgency]}`}>
                  <div className={styles.deadlineDate}>{deadline.date}</div>
                  <div className={styles.deadlineInfo}>
                    <h4>{deadline.title}</h4>
                    <p>{deadline.description}</p>
                    <span className={styles.deadlineImpact}>{deadline.impact}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className={styles.dashboard}>
          <div className={styles.taxSummary}>
            <div className={styles.summaryMain}>
              <div className={styles.summaryCard}>
                <span className={styles.summaryLabel}>You Paid</span>
                <span className={styles.summaryValue}>{formatCurrency(taxData.totalFederalTax)}</span>
                <span className={styles.summarySubtext}>in federal taxes</span>
              </div>
              <div className={styles.summaryCard}>
                <span className={styles.summaryLabel}>Effective Rate</span>
                <span className={styles.summaryValue}>{formatPercent(taxData.effectiveTaxRate)}</span>
                <span className={styles.summarySubtext}>of total income</span>
              </div>
              <div className={styles.summaryCard}>
                <span className={styles.summaryLabel}>Next Dollar Rate</span>
                <span className={styles.summaryValue}>{formatPercent(taxData.marginalTaxBracket)}</span>
                <span className={styles.summarySubtext}>marginal bracket</span>
              </div>
            </div>

            <div className={styles.incomeBreakdown}>
              <h4>Income Sources</h4>
              <div className={styles.breakdownBars}>
                {taxData.incomeBreakdown.wages > 0 && (
                  <div className={styles.breakdownItem}>
                    <span>Wages</span>
                    <span>{formatCurrency(taxData.incomeBreakdown.wages)}</span>
                  </div>
                )}
                {taxData.incomeBreakdown.capitalGains > 0 && (
                  <div className={styles.breakdownItem}>
                    <span>Capital Gains</span>
                    <span>{formatCurrency(taxData.incomeBreakdown.capitalGains)}</span>
                  </div>
                )}
                {taxData.incomeBreakdown.dividends > 0 && (
                  <div className={styles.breakdownItem}>
                    <span>Dividends</span>
                    <span>{formatCurrency(taxData.incomeBreakdown.dividends)}</span>
                  </div>
                )}
                {taxData.incomeBreakdown.business > 0 && (
                  <div className={styles.breakdownItem}>
                    <span>Business Income</span>
                    <span>{formatCurrency(taxData.incomeBreakdown.business)}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className={styles.twoColumn}>
            <div className={styles.insightsSection}>
              <h3 className={styles.sectionTitle}>Money Opportunities</h3>
              <p className={styles.sectionSubtitle}>Actions ranked by potential savings</p>
              
              {taxData.insights && taxData.insights.length > 0 ? (
                <div className={styles.insightsList}>
                  {taxData.insights.map((insight, i) => (
                    <div 
                      key={i} 
                      className={`${styles.insightCard} ${styles[insight.severity]}`}
                    >
                      <div className={styles.insightContent}>
                        <h4>{insight.title}</h4>
                        <p>{insight.description}</p>
                      </div>
                      <div className={styles.insightAction}>
                        {insight.potentialImpact && (
                          <span className={styles.insightImpact}>
                            Save {formatCurrency(insight.potentialImpact)}
                          </span>
                        )}
                        <button className={styles.insightCta}>
                          {insight.action || 'See Strategy'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className={styles.noInsights}>
                  <p>We're analyzing your return for optimization opportunities...</p>
                </div>
              )}
            </div>

            <div className={styles.calendarSection}>
              <h3 className={styles.sectionTitle}>Tax Timing Calendar</h3>
              <p className={styles.sectionSubtitle}>Upcoming deadlines & decision windows</p>
              <div className={styles.deadlinesList}>
                {taxDeadlines.map((deadline, i) => (
                  <div key={i} className={`${styles.deadlineCard} ${styles[deadline.urgency]}`}>
                    <div className={styles.deadlineDate}>{deadline.date}</div>
                    <div className={styles.deadlineInfo}>
                      <h4>{deadline.title}</h4>
                      <span className={styles.deadlineImpact}>{deadline.impact}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className={styles.scenarioSection}>
            <div className={styles.scenarioHeader}>
              <div>
                <h3 className={styles.sectionTitle}>What-If Calculator</h3>
                <p className={styles.sectionSubtitle}>Model decisions before you make them</p>
              </div>
              {!showScenarioBuilder && (
                <button 
                  className={styles.newScenarioButton}
                  onClick={() => setShowScenarioBuilder(true)}
                >
                  + Run New Scenario
                </button>
              )}
            </div>

            {showScenarioBuilder && (
              <div className={styles.scenarioBuilder}>
                <div className={styles.scenarioTypes}>
                  {scenarioTypes.map((type) => (
                    <button
                      key={type.id}
                      className={`${styles.scenarioType} ${activeScenario === type.id ? styles.active : ''}`}
                      onClick={() => setActiveScenario(type.id)}
                    >
                      <span className={styles.scenarioIcon}>{type.icon}</span>
                      <div className={styles.scenarioTypeText}>
                        <span className={styles.scenarioTypeName}>{type.name}</span>
                        <span className={styles.scenarioTypeDesc}>{type.description}</span>
                      </div>
                    </button>
                  ))}
                </div>

                {activeScenario === 'gain_realization' && (
                  <div className={styles.scenarioInputs}>
                    <label>
                      Gain Amount
                      <input 
                        type="number"
                        placeholder="50000"
                        value={scenarioInputs.gainAmount || ''}
                        onChange={(e) => setScenarioInputs({...scenarioInputs, gainAmount: e.target.value})}
                      />
                    </label>
                    <label>
                      Holding Period
                      <select 
                        value={scenarioInputs.holdingPeriod || ''}
                        onChange={(e) => setScenarioInputs({...scenarioInputs, holdingPeriod: e.target.value})}
                      >
                        <option value="">Select...</option>
                        <option value="short">Short-term (&lt; 1 year)</option>
                        <option value="long">Long-term (&gt; 1 year)</option>
                      </select>
                    </label>
                  </div>
                )}

                {activeScenario === 'charitable_giving' && (
                  <div className={styles.scenarioInputs}>
                    <label>
                      Donation Amount
                      <input 
                        type="number"
                        placeholder="10000"
                        value={scenarioInputs.donationAmount || ''}
                        onChange={(e) => setScenarioInputs({...scenarioInputs, donationAmount: e.target.value})}
                      />
                    </label>
                    <label>
                      Donation Type
                      <select 
                        value={scenarioInputs.donationType || ''}
                        onChange={(e) => setScenarioInputs({...scenarioInputs, donationType: e.target.value})}
                      >
                        <option value="">Select...</option>
                        <option value="cash">Cash</option>
                        <option value="appreciated_stock">Appreciated Stock</option>
                        <option value="daf">Donor-Advised Fund</option>
                      </select>
                    </label>
                  </div>
                )}

                {activeScenario === 'retirement_contribution' && (
                  <div className={styles.scenarioInputs}>
                    <label>
                      Contribution Amount
                      <input 
                        type="number"
                        placeholder="23000"
                        value={scenarioInputs.contributionAmount || ''}
                        onChange={(e) => setScenarioInputs({...scenarioInputs, contributionAmount: e.target.value})}
                      />
                    </label>
                    <label>
                      Account Type
                      <select 
                        value={scenarioInputs.accountType || ''}
                        onChange={(e) => setScenarioInputs({...scenarioInputs, accountType: e.target.value})}
                      >
                        <option value="">Select...</option>
                        <option value="401k">Traditional 401(k)</option>
                        <option value="ira">Traditional IRA</option>
                        <option value="roth_401k">Roth 401(k)</option>
                        <option value="roth_ira">Roth IRA</option>
                      </select>
                    </label>
                  </div>
                )}

                {activeScenario === 'roth_conversion' && (
                  <div className={styles.scenarioInputs}>
                    <label>
                      Conversion Amount
                      <input 
                        type="number"
                        placeholder="50000"
                        value={scenarioInputs.conversionAmount || ''}
                        onChange={(e) => setScenarioInputs({...scenarioInputs, conversionAmount: e.target.value})}
                      />
                    </label>
                  </div>
                )}

                <div className={styles.scenarioActions}>
                  <button 
                    className={styles.cancelButton}
                    onClick={() => {
                      setShowScenarioBuilder(false);
                      setActiveScenario('');
                      setScenarioInputs({});
                    }}
                  >
                    Cancel
                  </button>
                  <button 
                    className={styles.runButton}
                    onClick={runScenario}
                    disabled={!activeScenario || isCalculating}
                  >
                    {isCalculating ? 'Calculating...' : 'Calculate Tax Impact'}
                  </button>
                </div>
              </div>
            )}

            {scenarios.length > 0 && (
              <div className={styles.scenarioResults}>
                <h4 className={styles.resultsTitle}>Your Scenarios</h4>
                {scenarios.map((scenario) => (
                  <div key={scenario.id} className={styles.scenarioResult}>
                    <div className={styles.scenarioResultHeader}>
                      <span className={styles.scenarioName}>{scenario.name}</span>
                    </div>
                    {scenario.results && (
                      <div className={styles.scenarioMetrics}>
                        <div className={styles.scenarioMetric}>
                          <span className={styles.label}>New Tax Bill</span>
                          <span className={styles.value}>{formatCurrency(scenario.results.newTax)}</span>
                        </div>
                        <div className={styles.scenarioMetric}>
                          <span className={styles.label}>Change</span>
                          <span className={`${styles.value} ${scenario.results.taxDelta > 0 ? styles.negative : styles.positive}`}>
                            {scenario.results.taxDelta > 0 ? '+' : ''}{formatCurrency(scenario.results.taxDelta)}
                          </span>
                        </div>
                        <div className={styles.scenarioMetric}>
                          <span className={styles.label}>New Rate</span>
                          <span className={styles.value}>{formatPercent(scenario.results.effectiveRate)}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
